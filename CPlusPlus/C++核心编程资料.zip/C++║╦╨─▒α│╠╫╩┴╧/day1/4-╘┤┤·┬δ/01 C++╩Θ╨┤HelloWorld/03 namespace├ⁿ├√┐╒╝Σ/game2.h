#include <iostream>
using namespace std;

namespace kingGlory
{
	void goAtk();
}

