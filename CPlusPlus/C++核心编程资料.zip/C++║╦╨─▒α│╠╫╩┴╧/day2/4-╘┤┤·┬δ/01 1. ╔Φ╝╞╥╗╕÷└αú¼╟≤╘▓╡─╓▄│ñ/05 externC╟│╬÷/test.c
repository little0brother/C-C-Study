#include "test.h"

void show()
{
	printf("hello world\n");

}