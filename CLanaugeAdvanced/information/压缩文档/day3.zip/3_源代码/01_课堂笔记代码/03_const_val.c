const int aa = 100;

void test()
{

}