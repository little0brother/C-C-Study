#pragma  once

#include "a.h"

void fun_b();