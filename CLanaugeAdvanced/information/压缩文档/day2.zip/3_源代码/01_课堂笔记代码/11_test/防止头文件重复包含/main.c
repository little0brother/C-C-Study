#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "a.h"

int main(void)
{
	

	printf("\n");
	system("pause");
	return 0;
}