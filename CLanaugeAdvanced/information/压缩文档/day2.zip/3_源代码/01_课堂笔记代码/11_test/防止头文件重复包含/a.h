#pragma  once

#include "b.h"

void fun_a();