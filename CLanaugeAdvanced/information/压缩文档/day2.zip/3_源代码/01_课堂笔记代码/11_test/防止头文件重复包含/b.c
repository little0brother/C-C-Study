
void fun_b()
{

}